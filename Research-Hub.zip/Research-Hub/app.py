from flask import Flask, render_template, request, redirect, url_for, flash, session
from flask_bcrypt import Bcrypt  # For password hashing and verification
from flask_mysqldb import MySQL  # For MySQL connection using Flask extension
from werkzeug.utils import secure_filename
import os
from flask import send_from_directory, abort
from datetime import timedelta


app = Flask(__name__)
app.secret_key = "3828dfef8f8d6fd8f"  

UPLOAD_FOLDER = 'uploads/'
ALLOWED_EXTENSIONS = {'pdf', 'docx'}


# Initialize bcrypt for password hashing
bcrypt = Bcrypt(app)

# Database Configuration
app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'root'
app.config['MYSQL_PASSWORD'] = '123456'
app.config['MYSQL_DB'] = 'user_auth'
app.config['ALLOWED_EXTENSIONS'] = {'pdf', 'docx'}
app.config['UPLOAD_FOLDER'] = 'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.config['PERMANENT_SESSION_LIFETIME'] = timedelta(days=1) 

# Initialize MySQL
mysql = MySQL(app)



@app.route('/download/<filename>')
def download_file(filename):
    print(f"Attempting to download: {filename}")  # Debugging line
    try:
        # Serve the file from the uploads folder
        return send_from_directory(app.config['UPLOAD_FOLDER'], filename, as_attachment=True)
    except FileNotFoundError:
        abort(404, description="File not found")





# Route for handling signup form
@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        username = request.form['username']
        email = request.form['email']
        password = request.form['password']
        confirm_password = request.form['confirm_password']
        
        if password != confirm_password:
            flash('Passwords do not match', 'danger')
            return redirect(url_for('signup'))
        
        hashed_password = bcrypt.generate_password_hash(password).decode('utf-8')
        
        cursor = mysql.connection.cursor()
        cursor.execute('SELECT * FROM user WHERE email = %s', (email,))
        existing_user = cursor.fetchone()
        
        if existing_user:
            flash('Email already exists, please log in or use a different email.', 'danger')
            return redirect(url_for('signup'))
        
        cursor.execute('INSERT INTO user (username, email, password) VALUES (%s, %s, %s)', 
                       (username, email, hashed_password))
        mysql.connection.commit()
        cursor.close()
        
        flash('Account created successfully! Please log in.', 'success')
        return redirect(url_for('signin'))
    return render_template('signup.html')

@app.route('/signin', methods=['GET', 'POST'])
def signin():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']
        remember_me = request.form.get('remember_me')  # Check if Remember Me is selected
        
        cursor = mysql.connection.cursor()
        # Fetch only the required columns (id, username, password)
        cursor.execute('SELECT id, username, password FROM user WHERE email = %s', (email,))
        user = cursor.fetchone()
        cursor.close()

        if user:
            # Unpack the user data (id, username, and password)
            user_id, username, db_password = user
            # Check if the provided password matches the stored hashed password
            if bcrypt.check_password_hash(db_password, password):
                session['user_id'] = user_id
                session['username'] = username

                # If Remember Me is checked, set the session to permanent
                if remember_me:
                    session.permanent = True  # Set the session to permanent
                else:
                    session.permanent = False  # Otherwise, keep the session temporary

                return redirect(url_for('dashboard'))  # Redirect to dashboard after successful login
            else:
                flash('Invalid Credentails, Please try again.', 'danger')
        else:
            flash('No account found with that email. Please sign up.', 'danger')

    return render_template('signin.html')


@app.route('/')
def index():
    return render_template('outer.html')

@app.route('/about')
def aboutus():
    return render_template('about.html')

@app.route('/dashboard', methods=['GET', 'POST'])
def dashboard():
    if 'user_id' not in session:
        flash('Session time out, login again.', 'danger')
        return redirect(url_for('signin'))

    search_query = request.form.get('search', '')  # Get the search query if present
    cursor = mysql.connection.cursor()

    # Modify the query to fetch all paper details including abstract
    if search_query:
        cursor.execute(
            "SELECT * FROM papers WHERE paper_name LIKE %s OR authors LIKE %s",
            (f"%{search_query}%", f"%{search_query}%")
        )
    else:
        cursor.execute("SELECT * FROM papers WHERE user_id = %s", (session['user_id'],))
    
    papers = cursor.fetchall()  # Fetch the paper details including the abstract
    cursor.close()
    
    return render_template('dashboard.html', papers=papers, search_query=search_query)



# Check allowed file extension
def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

@app.route('/upload', methods=['GET', 'POST'])
def upload():
    if 'user_id' not in session:
        return redirect(url_for('signin'))

    if request.method == 'POST':
        paper_name = request.form['paper_name']
        authors = request.form['authors']
        publication_date = request.form['publication_date']
        abstract = request.form['abstract']  # Get the abstract from the form
        user_id = session['user_id']
        
        # Check if a file is selected
        file = request.files.get('file')
        if file and allowed_file(file.filename):
            # Secure the filename and save the file
            filename = secure_filename(file.filename)  # Secure the filename
            file_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)  # Store relative path
            file.save(file_path)  # Save the file to the uploads folder

            # Save paper details to the database, including abstract
            cursor = mysql.connection.cursor()
            cursor.execute(
                "INSERT INTO papers (paper_name, authors, publication_date, abstract, user_id, file_path) VALUES (%s, %s, %s, %s, %s, %s)",
                (paper_name, authors, publication_date, abstract, user_id, filename)  # Include abstract
            )
            mysql.connection.commit()  # Commit the transaction
            cursor.close()

            flash('Paper uploaded successfully!', 'success')  # Show a success message
            return redirect(url_for('dashboard'))  # Redirect to the dashboard

        else:
            flash('Invalid file format. Only PDF and DOCX are allowed.', 'danger')  # Error message if file type is not allowed

    return render_template('upload.html')  # Render the upload page template


@app.route('/profile', methods=['GET', 'POST'])
def profile():
    if 'user_id' not in session:
        flash('Session time out, login again.', 'danger')
        return redirect(url_for('signin'))

    user_id = session['user_id']
    cursor = mysql.connection.cursor()

    # Fetch the user data from the database
    cursor.execute("SELECT email, profession, member_since FROM user WHERE id = %s", (user_id,))
    user = cursor.fetchone()

    if request.method == 'POST':
        # Update the profession if it's provided
        profession = request.form.get('profession')
        cursor.execute(
            "UPDATE user SET profession = %s WHERE id = %s", (profession, user_id)
        )
        mysql.connection.commit()
        flash('Profile updated successfully!', 'success')

    cursor.close()

    # Render the profile page with user data
    return render_template('profile.html', user=user)



@app.route('/logout')
def logout():
    session.clear()
    flash('You have been logged out.', 'success')
    return redirect(url_for('signin'))

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0')
